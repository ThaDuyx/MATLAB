Main file to open is generateDiffusionMidi
